# Medium to Freedium Redirect

Extensión para Firefox que redirige automáticamente cualquier enlace de **medium.com** hacia **freedium.cfd**.

## 🚀 Instalación
1. Descarga el `.xpi` desde [AMO](https://addons.mozilla.org/).
2. O instala manualmente desde `about:addons` → **Instalar complemento desde archivo**.

## 🛠 Desarrollo
Clona el repo y carga como complemento temporal:

```bash
web-ext run